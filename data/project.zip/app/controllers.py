# -*- coding: utf-8 -*-
import cherrypy
from sponge import template

class HelloWorldController(object):
    @cherrypy.expose
    def index(self):
        return template.render_html('index.html')
