# -*- coding: utf-8 -*-

from app.controllers import HelloWorldController

class TestHelloWorldController:
    def test_index_renders_some_congratulations(self):
        ctrl = HelloWorldController()
        html = ctrl.index()

        assert 'Congratulations!' in html, "The html rendered by " \
               "HelloWorldController's should have some " \
               "congratulation message."
