# -*- coding: utf-8 -*-
import cherrypy
from os.path import dirname, abspath, join
from app.controllers import HelloWorldController

cherrypy.config['template.dir'] = join(abspath(dirname(__file__)), '..', '..', 'templates')

class TestHelloWorldController:
    def test_index_renders_some_congratulations(self):
        ctrl = HelloWorldController()
        html = ctrl.index()

        assert 'Congratulations!' in html, "The html rendered by " \
               "HelloWorldController's should have some " \
               "congratulation message."
