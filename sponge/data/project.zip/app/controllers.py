# -*- coding: utf-8 -*-
from sponge import Controller
from sponge import route

from sponge.template import render_html

class HelloWorldController(Controller):
    @route('hello_index', '/')
    def index(self):
        return render_html('index.html')

    @route('hello_custom', '/:what')
    def custom_page(self, what):
        if what.lower() not in ('work', 'play'):
            return 'Invalid action: %s' % what
        return render_html('custom.html', {'action': what})
