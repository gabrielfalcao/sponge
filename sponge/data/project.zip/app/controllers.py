# -*- coding: utf-8 -*-
from sponge import route
from sponge import Controller
from sponge import template

class HelloWorldController(Controller):
    @route('hello_index', '/')
    def index(self):
        return template.render_html('index.html')

    @route('hello_custom', '/:what')
    def custom_page(self, what):
        if what.lower() not in ('work', 'play'):
            return 'Invalid action: %s' % what
        return template.render_html('custom.html', {'action': what})
